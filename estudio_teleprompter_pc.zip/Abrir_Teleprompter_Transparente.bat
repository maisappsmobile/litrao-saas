@echo off
title Iniciando Teleprompter Transparente...
start "" powershell.exe -ExecutionPolicy Bypass -NoProfile -WindowStyle Hidden -File "%~dp0teleprompter_nativo.ps1"
exit
