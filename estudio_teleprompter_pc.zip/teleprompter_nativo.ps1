﻿Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$csharpCode = @'
using System;
using System.Runtime.InteropServices;
using System.Windows.Interop;

public class Win32PrompterHook {
    public const int WM_NCHITTEST = 0x0084;
    public const int HTTRANSPARENT = -1;

    public static bool PassThrough = true;
    public static int HeaderHeight = 44;

    [StructLayout(LayoutKind.Sequential)]
    public struct POINT {
        public int x;
        public int y;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [DllImport("user32.dll")]
    public static extern bool ScreenToClient(IntPtr hWnd, ref POINT lpPoint);

    [DllImport("user32.dll")]
    public static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);

    public static void Attach(IntPtr hwnd) {
        HwndSource source = HwndSource.FromHwnd(hwnd);
        if (source != null) {
            source.AddHook(new HwndSourceHook(WndProc));
        }
    }

    private static IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled) {
        if (msg == WM_NCHITTEST && PassThrough) {
            int screenX = (short)((int)lParam & 0xFFFF);
            int screenY = (short)(((int)lParam >> 16) & 0xFFFF);

            POINT pt;
            pt.x = screenX;
            pt.y = screenY;
            ScreenToClient(hwnd, ref pt);

            RECT rect;
            GetClientRect(hwnd, out rect);
            int width = rect.Right - rect.Left;
            int height = rect.Bottom - rect.Top;

            if (pt.y <= HeaderHeight) {
                return IntPtr.Zero;
            }

            if (pt.x >= (width - 32) && pt.y >= (height - 32)) {
                return IntPtr.Zero;
            }

            handled = true;
            return (IntPtr)HTTRANSPARENT;
        }
        return IntPtr.Zero;
    }
}
'@

Add-Type -TypeDefinition $csharpCode -Language CSharp -ReferencedAssemblies "PresentationCore", "WindowsBase"

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Teleprompter Transparente Oficial"
        Height="260" Width="820"
        MinHeight="130" MinWidth="380"
        WindowStyle="None"
        AllowsTransparency="True"
        Background="#38000000"
        Topmost="True"
        WindowStartupLocation="Manual"
        Left="280" Top="35">
    <Window.Resources>
        <Style TargetType="Button">
            <Setter Property="Background" Value="#CC1F2937"/>
            <Setter Property="Foreground" Value="#F9FAFB"/>
            <Setter Property="FontWeight" Value="Bold"/>
            <Setter Property="FontSize" Value="11"/>
            <Setter Property="Padding" Value="5,2"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="BorderBrush" Value="#88FFFFFF"/>
            <Setter Property="Cursor" Value="Hand"/>
        </Style>
    </Window.Resources>
    <Border Name="mainBorder" BorderBrush="#AAFBBF24" BorderThickness="1.5" CornerRadius="12" Padding="6,5,6,4">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
            </Grid.RowDefinitions>

            <!-- BARRA DE CONTROLE COMPACTA E INTUITIVA -->
            <Grid Grid.Row="0" Margin="0,0,0,4" Name="controlGrid">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>

                <!-- REPRODUÇÃO, VELOCIDADE & SELETOR DE ROTEIRO -->
                <StackPanel Grid.Column="0" Orientation="Horizontal">
                    <Button Name="btnPlay" Content="▶ PLAY" Background="#DD10B981" Foreground="#042F2E" Margin="0,0,3,0"/>
                    <Button Name="btnReset" Content="↺ Início" Margin="0,0,3,0"/>
                    
                    <!-- SELETOR DE ROTEIRO -->
                    <ComboBox Name="cmbRoteiros" Width="175" Height="22" FontSize="11" FontWeight="Bold" Margin="0,0,4,0" VerticalContentAlignment="Center" Background="#CC111827" Foreground="#F3F4F6">
                        <ComboBoxItem Content="1. Pedidos WhatsApp (45s)" IsSelected="True"/>
                        <ComboBoxItem Content="2. Cartão Fidelidade (45s)"/>
                        <ComboBoxItem Content="3. Top Consultores (50s)"/>
                        <ComboBoxItem Content="4. Apresentação Geral (2m)"/>
                    </ComboBox>

                    <Button Name="btnSlow" Content="-" ToolTip="Diminuir velocidade" Margin="0,0,1,0"/>
                    <TextBlock Name="txtSpeed" Text="1.6x" Foreground="#FBBF24" VerticalAlignment="Center" FontWeight="Bold" Margin="2,0"/>
                    <Button Name="btnFast" Content="+" ToolTip="Aumentar velocidade" Margin="1,0,4,0"/>
                    
                    <Button Name="btnModoClique" Content="🖱️ Clicar Atrás: SIM" Background="#DD059669" Foreground="White" ToolTip="Quando SIM, os cliques no texto passam direto para a plataforma do Litrão atrás!"/>
                </StackPanel>

                <!-- ARRASTAR JANELA -->
                <TextBlock Grid.Column="1" Text="⠿ Arraste" Foreground="#E5E7EB" FontSize="11" FontWeight="SemiBold" VerticalAlignment="Center" HorizontalAlignment="Center" Cursor="SizeAll" Name="lblDrag"/>

                <!-- TAMANHO, FONTE, FUNDO E FECHAR -->
                <StackPanel Grid.Column="2" Orientation="Horizontal">
                    <Button Name="btnLargMinus" Content="Larg -" ToolTip="Diminuir largura" Margin="0,0,2,0"/>
                    <Button Name="btnLargPlus" Content="Larg +" ToolTip="Aumentar largura" Margin="0,0,2,0"/>
                    <Button Name="btnAltMinus" Content="Alt -" ToolTip="Diminuir altura" Margin="0,0,2,0"/>
                    <Button Name="btnAltPlus" Content="Alt +" ToolTip="Aumentar altura" Margin="0,0,2,0"/>
                    <Button Name="btnFontMinus" Content="A-" ToolTip="Diminuir letras" Margin="0,0,2,0"/>
                    <Button Name="btnFontPlus" Content="A+" ToolTip="Aumentar letras" Margin="0,0,3,0"/>
                    <Button Name="btnFundo" Content="Fundo ◐" Margin="0,0,3,0" ToolTip="Muda nível de transparência"/>
                    <Button Name="btnToggleBarra" Content="▲ Ocultar" Margin="0,0,3,0" ToolTip="Oculta esta barra de botões"/>
                    <Button Name="btnClose" Content="✖" Background="#DDEF4444" Foreground="White"/>
                </StackPanel>
            </Grid>

            <!-- BOTÃO REABRIR BARRA (QUANDO OCULTA) -->
            <Button Name="btnShowBarra" Content="▼ Menu" Visibility="Collapsed" HorizontalAlignment="Right" VerticalAlignment="Top" Margin="0,2,6,0" Panel.ZIndex="10"/>

            <!-- ÁREA DO TEXTO ROLANTE COM CONTORNO PRETO ROBUSTO -->
            <ScrollViewer Grid.Row="1" Name="scrollViewer" VerticalScrollBarVisibility="Hidden" HorizontalScrollBarVisibility="Disabled">
                <StackPanel Name="textPanel" Margin="12,12,12,190" HorizontalAlignment="Center">
                    <!-- PREENCHIDO DINAMICAMENTE PELO SCRIPT -->
                </StackPanel>
            </ScrollViewer>

            <!-- GRIP PARA PUXAR E REDIMENSIONAR LIVREMENTE COM O MOUSE (CANTO INFERIOR DIREITO) -->
            <Thumb Grid.Row="1" Name="resizeGrip" Width="26" Height="26" HorizontalAlignment="Right" VerticalAlignment="Bottom" Cursor="SizeNWSE" ToolTip="Clique e arraste para redimensionar a janela">
                <Thumb.Template>
                    <ControlTemplate>
                        <Grid Background="Transparent">
                            <Path Data="M 22,6 L 6,22 M 22,11 L 11,22 M 22,16 L 16,22" Stroke="#FBBF24" StrokeThickness="2.5" SnapsToDevicePixels="True"/>
                        </Grid>
                    </ControlTemplate>
                </Thumb.Template>
            </Thumb>
        </Grid>
    </Border>
</Window>
"@

$reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new($xaml))
$window = [System.Windows.Markup.XamlReader]::Load($reader)

# Elementos
$btnPlay = $window.FindName("btnPlay")
$btnReset = $window.FindName("btnReset")
$btnSlow = $window.FindName("btnSlow")
$btnFast = $window.FindName("btnFast")
$txtSpeed = $window.FindName("txtSpeed")
$btnModoClique = $window.FindName("btnModoClique")
$lblDrag = $window.FindName("lblDrag")
$cmbRoteiros = $window.FindName("cmbRoteiros")

$btnLargMinus = $window.FindName("btnLargMinus")
$btnLargPlus = $window.FindName("btnLargPlus")
$btnAltMinus = $window.FindName("btnAltMinus")
$btnAltPlus = $window.FindName("btnAltPlus")
$btnFontMinus = $window.FindName("btnFontMinus")
$btnFontPlus = $window.FindName("btnFontPlus")

$btnFundo = $window.FindName("btnFundo")
$btnClose = $window.FindName("btnClose")
$btnToggleBarra = $window.FindName("btnToggleBarra")
$btnShowBarra = $window.FindName("btnShowBarra")
$controlGrid = $window.FindName("controlGrid")
$scrollViewer = $window.FindName("scrollViewer")
$textPanel = $window.FindName("textPanel")
$resizeGrip = $window.FindName("resizeGrip")

# Hook Win32 para Atravessar Cliques na Área do Texto
$window.Add_SourceInitialized({
    $helper = New-Object System.Windows.Interop.WindowInteropHelper($window)
    [Win32PrompterHook]::Attach($helper.Handle)
})

# Arrastar janela
$lblDrag.Add_MouseLeftButtonDown({ $window.DragMove() })

# Alternar Modo de Clique
$btnModoClique.Add_Click({
    [Win32PrompterHook]::PassThrough = -not [Win32PrompterHook]::PassThrough
    if ([Win32PrompterHook]::PassThrough) {
        $btnModoClique.Content = "🖱️ Clicar Atrás: SIM"
        $btnModoClique.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#DD059669")
    } else {
        $btnModoClique.Content = "🖱️ Clicar Atrás: NÃO"
        $btnModoClique.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#DD4B5563")
    }
})

# Redimensionamento Livre
$resizeGrip.Add_DragDelta({
    $window.Width = [Math]::Max(380, $window.Width + $_.HorizontalChange)
    $window.Height = [Math]::Max(130, $window.Height + $_.VerticalChange)
})

# Ajustes de Janela
$btnLargMinus.Add_Click({ $window.Width = [Math]::Max(380, $window.Width - 60) })
$btnLargPlus.Add_Click({ $window.Width = [Math]::Min(1400, $window.Width + 60) })
$btnAltMinus.Add_Click({ $window.Height = [Math]::Max(130, $window.Height - 40) })
$btnAltPlus.Add_Click({ $window.Height = [Math]::Min(900, $window.Height + 40) })

# Função para criar TextBlock com contorno preto grosso
$script:curFont = 26
function Add-PrompterLine($text, $color, $size, $isBold, $isAction = $false, $top = 2, $bottom = 2) {
    $tb = New-Object System.Windows.Controls.TextBlock
    $tb.Text = $text
    $tb.Foreground = [System.Windows.Media.BrushConverter]::new().ConvertFromString($color)
    $tb.FontSize = $size
    $tb.FontWeight = if ($isBold) { [System.Windows.FontWeights]::Black } else { [System.Windows.FontWeights]::Bold }
    $tb.HorizontalAlignment = [System.Windows.HorizontalAlignment]::Center
    $tb.TextWrapping = [System.Windows.TextWrapping]::Wrap
    $tb.TextAlignment = [System.Windows.TextAlignment]::Center
    $tb.Margin = New-Object System.Windows.Thickness(0, $top, 0, $bottom)

    # Contorno Preto 360 Graus
    $shadow = New-Object System.Windows.Media.Effects.DropShadowEffect
    $shadow.Color = [System.Windows.Media.Colors]::Black
    $shadow.BlurRadius = 6
    $shadow.ShadowDepth = 0
    $shadow.Opacity = 1.0
    $shadow.RenderingBias = [System.Windows.Media.Effects.RenderingBias]::Quality
    $tb.Effect = $shadow

    $textPanel.Children.Add($tb) | Out-Null
}

# BANCO DOS 4 ROTEIROS
function Carregar-Roteiro($idx) {
    $textPanel.Children.Clear()
    $scrollViewer.ScrollToVerticalOffset(0)

    if ($idx -eq 0) {
        # ROTEIRO 1: PEDIDOS NO WHATSAPP (45s)
        Add-PrompterLine "• GANCHO FORTE •" "#93C5FD" 11 $true $true 0 6
        Add-PrompterLine "Se você vende Litrão da Herbalife" "White" $script:curFont $true
        Add-PrompterLine "e ainda anota pedidos em papel de pão" "White" $script:curFont $true
        Add-PrompterLine "ou no bloco de notas do celular..." "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "você está deixando pelo menos 2 mil reais na mesa todo mês!" "White" $script:curFont $true 4 14

        Add-PrompterLine "• DOR VISCERAL •" "#F87171" 11 $true $true 0 6
        Add-PrompterLine "Quantas vezes um cliente te chamou," "White" $script:curFont $true
        Add-PrompterLine "você demorou pra responder o cardápio," "White" $script:curFont $true
        Add-PrompterLine "ele comprou em outro lugar" "#FBBF24" $script:curFont $true
        Add-PrompterLine "ou você simplesmente esqueceu de cobrar o próximo galão?" "White" $script:curFont $true 4 14

        Add-PrompterLine "• MOSTRE A TELA NO PAINEL •" "#34D399" 11 $true $true 0 6
        Add-PrompterLine "Olha como isso acabou:" "White" $script:curFont $true
        Add-PrompterLine "Com a plataforma oficial do Litrão do Reset," "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "o cliente clica no seu link próprio," "White" $script:curFont $true
        Add-PrompterLine "escolhe sabores, adicionais de fibras e proteínas," "White" $script:curFont $true
        Add-PrompterLine "e o pedido chega prontinho no seu WhatsApp!" "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "E o sistema ainda te avisa a hora exata que o Litrão dele vai acabar!" "White" $script:curFont $true 4 14

        Add-PrompterLine "• APONTE PARA O QR CODE NO CANTO •" "#34D399" 11 $true $true 0 6
        Add-PrompterLine "Aponte a câmera pro QR Code aqui na tela" "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "ou clique no link da minha bio." "White" $script:curFont $true
        Add-PrompterLine "Você tem 7 dias grátis pra testar e dobrar suas vendas sem gastar 1 real!" "#34D399" $script:curFont $true 4 10
    }
    elseif ($idx -eq 1) {
        # ROTEIRO 2: CARTÃO FIDELIDADE (45s)
        Add-PrompterLine "• GANCHO MAGNÉTICO •" "#93C5FD" 11 $true $true 0 6
        Add-PrompterLine "Como fazer o mesmo cliente comprar" "White" $script:curFont $true
        Add-PrompterLine "4 Litrões de Reset de você todo santo mês," "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "sem você precisar ficar mandando mensagem chata insistindo?" "White" $script:curFont $true 4 14

        Add-PrompterLine "• O SEGREDO DOS TOP LÍDERES •" "#F87171" 11 $true $true 0 6
        Add-PrompterLine "O maior erro é vender hoje" "White" $script:curFont $true
        Add-PrompterLine "e torcer pro cliente lembrar de pedir semana que vem." "White" $script:curFont $true
        Add-PrompterLine "Os consultores que mais faturam usam Retenção Automática!" "#FBBF24" $script:curFont $true 4 14

        Add-PrompterLine "• MOSTRE O CARTÃO FIDELIDADE NA TELA •" "#34D399" 11 $true $true 0 6
        Add-PrompterLine "Aqui na plataforma do Litrão do Reset," "White" $script:curFont $true
        Add-PrompterLine "seu cliente tem um Cartão Fidelidade Digital no celular!" "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "A cada Litrão ou detox que ele toma, ganha um carimbo." "White" $script:curFont $true
        Add-PrompterLine "Ao completar 10 carimbos, ganha um brinde exclusivo no seu Espaço!" "#FBBF24" $script:curFont $true
        Add-PrompterLine "Ele passa a comprar de você por vício de completar a cartela!" "White" $script:curFont $true 4 14

        Add-PrompterLine "• APONTE PARA O QR CODE •" "#34D399" 11 $true $true 0 6
        Add-PrompterLine "Quer esse cartão rodando no seu negócio hoje?" "White" $script:curFont $true
        Add-PrompterLine "Aponte o celular pro QR Code aqui no cantinho" "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "e pegue sua vaga de Membro Fundador com 7 dias grátis!" "#34D399" $script:curFont $true 4 10
    }
    elseif ($idx -eq 2) {
        # ROTEIRO 3: TOP CONSULTORES DE 2026 (50s)
        Add-PrompterLine "• GANCHO PROVOCATIVO •" "#93C5FD" 11 $true $true 0 6
        Add-PrompterLine "Para de mandar foto pesada de cardápio em PDF" "White" $script:curFont $true
        Add-PrompterLine "que ninguém abre no WhatsApp!" "#F87171" ($script:curFont + 2) $true
        Add-PrompterLine "O jogo das vendas de Litrão mudou completamente." "White" $script:curFont $true 4 14

        Add-PrompterLine "• A NOVA REALIDADE •" "#93C5FD" 11 $true $true 0 6
        Add-PrompterLine "Quem tem página moderna e rápida vende 3x mais" "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "do que quem fica digitando preço e chave Pix na mão!" "White" $script:curFont $true 4 14

        Add-PrompterLine "• MOSTRE A FERRAMENTA NA TELA •" "#34D399" 11 $true $true 0 6
        Add-PrompterLine "Com a plataforma do Litrão do Reset, você tem:" "White" $script:curFont $true
        Add-PrompterLine "Seu catálogo digital próprio," "#FBBF24" $script:curFont $true
        Add-PrompterLine "Extrator de Contatos pra achar clientes na sua cidade," "#FBBF24" $script:curFont $true
        Add-PrompterLine "e ainda cadastra novos consultores na sua equipe," "White" $script:curFont $true
        Add-PrompterLine "dando 7 dias grátis pra eles começarem faturando com você!" "#34D399" ($script:curFont + 2) $true 4 14

        Add-PrompterLine "• CHAMADA FINAL •" "#34D399" 11 $true $true 0 6
        Add-PrompterLine "Aponte a câmera para o QR Code agora mesmo," "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "ou clique no link logo abaixo deste vídeo." "White" $script:curFont $true
        Add-PrompterLine "Te vejo lá dentro da plataforma para acelerar seus resultados!" "White" $script:curFont $true 4 10
    }
    else {
        # ROTEIRO 4: APRESENTAÇÃO GERAL COMPLETA (2 a 3 min)
        Add-PrompterLine "ABERTURA COM SORRISO E FIRMEZA" "#93C5FD" 11 $true $true 0 6
        Add-PrompterLine "Olá líder, olá consultor!" "White" ($script:curFont + 2) $true
        Add-PrompterLine "Meu nome é Edwan Braga." "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "Hoje eu quero te apresentar a plataforma oficial" "White" $script:curFont $true
        Add-PrompterLine "do Litrão do Reset!" "#FBBF24" ($script:curFont + 2) $true 0 16

        Add-PrompterLine "• RESPIRE E MOSTRE A TELA NO PAINEL •" "#34D399" 11 $true $true 0 10
        Add-PrompterLine "Esta ferramenta foi criada sob medida" "White" $script:curFont $true
        Add-PrompterLine "para você que quer multiplicar suas vendas" "White" $script:curFont $true
        Add-PrompterLine "e gerenciar toda a sua rede de distribuidores." "White" $script:curFont $true 0 16

        Add-PrompterLine "• MOSTRE OS PRODUTOS NA TELA •" "#34D399" 11 $true $true 0 10
        Add-PrompterLine "Seus clientes acessam uma página moderna," "White" $script:curFont $true
        Add-PrompterLine "onde escolhem os pacotes do Litrão" "White" $script:curFont $true
        Add-PrompterLine "e fazem o pedido direto no seu WhatsApp!" "#FBBF24" ($script:curFont + 2) $true 0 16

        Add-PrompterLine "• MOSTRE O BOTÃO CADASTRAR CONSULTOR •" "#34D399" 11 $true $true 0 10
        Add-PrompterLine "E aqui no seu painel de controle:" "White" $script:curFont $true
        Add-PrompterLine "Você cadastra novos consultores da sua equipe," "White" $script:curFont $true
        Add-PrompterLine "e eles já recebem 7 dias grátis para começar!" "#FBBF24" $script:curFont $true 0 16

        Add-PrompterLine "• OLHE PARA A CÂMERA E APONTE PARA O QR CODE •" "#34D399" 11 $true $true 0 10
        Add-PrompterLine "Para ativar o seu acesso agora mesmo" "White" $script:curFont $true
        Add-PrompterLine "com a condição de Membro Fundador," "#FBBF24" ($script:curFont + 2) $true
        Add-PrompterLine "aponte a câmera do seu celular para este QR Code," "White" $script:curFont $true
        Add-PrompterLine "ou clique no link logo abaixo deste vídeo!" "#FBBF24" $script:curFont $true 0 16

        Add-PrompterLine "Te vejo lá dentro da plataforma para acelerar seus resultados!" "White" $script:curFont $true 4 10
    }
}

# Inicializa no Roteiro 1
Carregar-Roteiro(0)

# Evento de Troca de Roteiro
$cmbRoteiros.Add_SelectionChanged({
    if ($cmbRoteiros.SelectedIndex -ge 0) {
        $timer.Stop()
        $script:isPlaying = $false
        $btnPlay.Content = "▶ PLAY"
        $btnPlay.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#DD10B981")
        Carregar-Roteiro($cmbRoteiros.SelectedIndex)
    }
})

# Ajustes de Fonte
$btnFontMinus.Add_Click({
    $script:curFont = [Math]::Max(16, $script:curFont - 2)
    Carregar-Roteiro($cmbRoteiros.SelectedIndex)
})
$btnFontPlus.Add_Click({
    $script:curFont = [Math]::Min(44, $script:curFont + 2)
    Carregar-Roteiro($cmbRoteiros.SelectedIndex)
})

# Timer de rolagem contínua automática
$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(20)
$script:speed = 1.6
$script:isPlaying = $false

$timer.Add_Tick({
    $scrollViewer.ScrollToVerticalOffset($scrollViewer.VerticalOffset + $script:speed)
    if ($scrollViewer.VerticalOffset -ge ($scrollViewer.ScrollableHeight - 5)) {
        $timer.Stop()
        $script:isPlaying = $false
        $btnPlay.Content = "▶ PLAY"
        $btnPlay.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#DD10B981")
    }
})

# Play / Pausa
$btnPlay.Add_Click({
    if ($script:isPlaying) {
        $timer.Stop()
        $script:isPlaying = $false
        $btnPlay.Content = "▶ PLAY"
        $btnPlay.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#DD10B981")
    } else {
        $timer.Start()
        $script:isPlaying = $true
        $btnPlay.Content = "⏸ PAUSAR"
        $btnPlay.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#DDF59E0B")
    }
})

# Reiniciar
$btnReset.Add_Click({
    $timer.Stop()
    $script:isPlaying = $false
    $btnPlay.Content = "▶ PLAY"
    $btnPlay.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString("#DD10B981")
    $scrollViewer.ScrollToVerticalOffset(0)
})

# Velocidade
$btnSlow.Add_Click({
    $script:speed = [Math]::Max(0.4, $script:speed - 0.3)
    $txtSpeed.Text = "$([Math]::Round($script:speed, 1))x"
})
$btnFast.Add_Click({
    $script:speed = [Math]::Min(5.0, $script:speed + 0.3)
    $txtSpeed.Text = "$([Math]::Round($script:speed, 1))x"
})

# Alternar transparência de fundo
$script:opacidades = @("#38000000", "#55000000", "#75000000", "#00000000", "#18000000")
$script:opIndex = 0
$btnFundo.Add_Click({
    $script:opIndex = ($script:opIndex + 1) % $script:opacidades.Length
    $window.Background = [System.Windows.Media.BrushConverter]::new().ConvertFromString($script:opacidades[$script:opIndex])
})

# Ocultar / Mostrar Barra de Botões
$btnToggleBarra.Add_Click({
    $controlGrid.Visibility = [System.Windows.Visibility]::Collapsed
    $btnShowBarra.Visibility = [System.Windows.Visibility]::Visible
    [Win32PrompterHook]::HeaderHeight = 32
})
$btnShowBarra.Add_Click({
    $controlGrid.Visibility = [System.Windows.Visibility]::Visible
    $btnShowBarra.Visibility = [System.Windows.Visibility]::Collapsed
    [Win32PrompterHook]::HeaderHeight = 44
})

# Atalhos de Teclado
$window.Add_KeyDown({
    if ($_.Key -eq [System.Windows.Input.Key]::Space) {
        $btnPlay.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
    elseif ($_.Key -eq [System.Windows.Input.Key]::Up) {
        $btnFast.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
    elseif ($_.Key -eq [System.Windows.Input.Key]::Down) {
        $btnSlow.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
    elseif ($_.Key -eq [System.Windows.Input.Key]::R) {
        $btnReset.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
    elseif ($_.Key -eq [System.Windows.Input.Key]::F8) {
        $btnModoClique.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
    elseif ($_.Key -eq [System.Windows.Input.Key]::Escape) {
        $btnClose.RaiseEvent([System.Windows.RoutedEventArgs]::new([System.Windows.Controls.Button]::ClickEvent))
    }
})

# Fechar
$btnClose.Add_Click({
    $timer.Stop()
    $window.Close()
})

$window.ShowDialog() | Out-Null
