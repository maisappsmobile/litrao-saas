/**
 * ResetFIT - Módulo de Extração Automática de Grupos do Facebook Pro
 * Injetado em páginas do Facebook para permitir extração turbo de contatos,
 * acúmulo contínuo em memória anti-virtualização e seleção direta de público/Kanban.
 */

(function () {
  'use strict';

  if (window.__RESETFIT_FACEBOOK_INJECTED__) {
    console.log('[ResetFIT Facebook] Módulo já ativo nesta página.');
    return;
  }
  window.__RESETFIT_FACEBOOK_INJECTED__ = true;

  console.log('[ResetFIT Facebook] Módulo de extração turbo carregado com sucesso!');

  // Cache persistente em memória no contexto da janela para reter TODOS os membros encontrados
  // mesmo quando a virtualização do DOM do Facebook recicla e remove nós do topo.
  if (!window.__RESETFIT_FB_MEMBROS_CACHE__) {
    window.__RESETFIT_FB_MEMBROS_CACHE__ = new Map();
  }

  let leadsExtraidosCache = [];
  let cancelandoRolagemFb = false;
  let rolagemEmExecucao = false;

  // =======================================================
  // MOTOR UNIVERSAL DE RESOLUÇÃO DE SPINTAX E TAGS (FACEBOOK)
  // =======================================================
  function processarSpintaxETags(texto, contato = {}) {
    if (!texto || typeof texto !== 'string') return '';
    let res = texto;

    // 1. Saudação Inteligente por Turno do Dia
    const hora = new Date().getHours();
    const saudacaoManha = ['Bom dia', 'Olá, bom dia', 'Oi, bom dia', 'Oie, bom dia'];
    const saudacaoTarde = ['Boa tarde', 'Olá, boa tarde', 'Oi, boa tarde', 'Oie, boa tarde'];
    const saudacaoNoite = ['Boa noite', 'Olá, boa noite', 'Oi, boa noite'];
    const listaSaudacoes = (hora >= 5 && hora < 12) ? saudacaoManha : (hora >= 12 && hora < 18) ? saudacaoTarde : saudacaoNoite;
    const saudacaoSorteada = listaSaudacoes[Math.floor(Math.random() * listaSaudacoes.length)];

    res = res.replace(/\{(?:saudacao|saudação|turno|cumprimento)\}/gi, saudacaoSorteada);

    // 2. Extrai e Formata Primeiro Nome Humanizado
    let pNome = '';
    if (contato && contato.nome && typeof contato.nome === 'string') {
      const nomeLimpo = contato.nome.trim();
      if (!nomeLimpo.match(/^(\+|id_|\d)/)) {
        const primeiro = nomeLimpo.split(/[\s,;-]+/)[0] || '';
        if (primeiro.length >= 2) {
          pNome = primeiro.charAt(0).toUpperCase() + primeiro.slice(1).toLowerCase();
        }
      }
    }

    const regexNome = /\{(?:nome|primeiro_nome|primeiro nome|primeironome|cliente|lead|contato)\}/gi;
    if (pNome) {
      res = res.replace(regexNome, pNome);
    } else {
      res = res.replace(regexNome, '');
    }

    // 3. Código / Protocolo / Ref Aleatória Anti-Bloqueio
    const hash = Math.floor(1000 + Math.random() * 9000);
    res = res.replace(/\{(?:ref\s*#|protocolo|ticket)\}/gi, '#' + hash);
    res = res.replace(/\{(?:aleatorio|aleatório|codigo|código|hash|num_aleatorio)\}/gi, String(hash));
    res = res.replace(/\{(?:ref|referencia|referência)\}/gi, 'Ref #' + hash);

    // 4. Data, Hora e Dia da Semana
    const diasSemana = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
    const agora = new Date();
    res = res.replace(/\{(?:dia|dia_semana)\}/gi, diasSemana[agora.getDay()]);
    res = res.replace(/\{hoje\}/gi, 'hoje');
    res = res.replace(/\{data\}/gi, agora.toLocaleDateString('pt-BR'));
    res = res.replace(/\{hora\}/gi, agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }));

    // 5. Spintax Multinível / Recursivo (resolve todas as opções {a|b|c})
    let anterior = '';
    let limite = 12;
    while (limite > 0 && res !== anterior) {
      anterior = res;
      limite--;
      res = res.replace(/\{([^{}]+)\}/g, (match, conteudo) => {
        if (conteudo.includes('|')) {
          const opcoes = conteudo.split('|');
          const escolhida = opcoes[Math.floor(Math.random() * opcoes.length)];
          return (escolhida !== undefined) ? escolhida.trim() : '';
        }
        return match;
      });
    }

    // 6. Higienização de chaves residuais
    res = res.replace(/\{([^{}]+)\}/g, (match, conteudo) => {
      if (conteudo.includes('|')) {
        const opcoes = conteudo.split('|');
        return opcoes[Math.floor(Math.random() * opcoes.length)].trim();
      }
      if (/ref|num|cod/i.test(conteudo)) {
        return '#' + hash;
      }
      return '';
    });

    // 7. Limpeza Estética e Ajuste de Pontuação Órfã
    res = res
      .replace(/\s+([,.\?!;:])/g, '$1')
      .replace(/([,;])\s*([,;])/g, '$1')
      .replace(/\s{2,}/g, ' ')
      .replace(/^[,.\s]+/, '')
      .trim();

    return res;
  }

  // Copia mensagem rápida para o membro do Facebook com todas as tags resolvidas
  window.__resetfitCopiarMensagemX1Facebook = function(nomeMembro, perfilUrl) {
    const templates = [
      "{saudacao} {nome}, {tudo bem?|como vai?|passando rapidinho!} Vi seu contato aqui no grupo e gostaria de te apresentar o método do Litrão do Reset para desinchar, queimar retenção e ter mais disposição. Quer que eu te mande os detalhes? Ref: #{aleatorio}",
      "{Oi|Olá|Oie} {nome}! {Tudo certinho por aí?|Como você está?} Chegou uma receita nova e super refrescante do Litrão do Reset essa semana no nosso Espaço. Gostaria de uma dose gratuita de degustação? Ref: #{aleatorio}"
    ];
    const escolhido = templates[Math.floor(Math.random() * templates.length)];
    const msg = processarSpintaxETags(escolhido, { nome: nomeMembro });

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(msg).then(() => {
        alert(`✅ Mensagem personalizada para ${nomeMembro.split(' ')[0]} copiada!\n\n"${msg}"\n\nAbra a conversa e pressione Ctrl+V para colar!`);
        if (perfilUrl) window.open(perfilUrl, '_blank');
      });
    }
  };

  // Listener delegado anti-CSP para botões X1
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.btn-resetfit-x1-copiar');
    if (!btn) return;
    const nome = btn.getAttribute('data-nome') || '';
    const perfil = btn.getAttribute('data-perfil') || '';
    if (typeof window.__resetfitCopiarMensagemX1Facebook === 'function') {
      window.__resetfitCopiarMensagemX1Facebook(nome, perfil);
    }
  });

  /**
   * Detecta o nome do grupo atual a partir do cabeçalho ou título da página
   */
  function obterNomeGrupoFacebook() {
    const h1 = document.querySelector('h1');
    if (h1 && h1.innerText && h1.innerText.trim().length > 2) {
      return h1.innerText.trim();
    }
    let title = document.title || '';
    title = title.replace(/\s*\|\s*Facebook\s*$/i, '').trim();
    if (title && title.length > 2) {
      return title;
    }
    return 'Grupo Facebook';
  }

  /**
   * Normaliza texto para validação de nomes
   */
  function normalizarTextoFb(str) {
    return String(str || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
  }

  /**
   * Extrai um identificador único para o perfil do Facebook
   */
  function extrairIdentificadorPerfilFb(url) {
    if (!url) return '';
    const raw = String(url).trim();
    const matchId = raw.match(/[?&]id=(\d+)/i) || raw.match(/\/user\/(\d+)/i);
    if (matchId) return 'id_' + matchId[1];
    const limpa = raw.split('?')[0].replace(/\/+$/, '').toLowerCase();
    const matchUser = limpa.match(/facebook\.com\/([a-zA-Z0-9\.\_\-]+)/i);
    if (matchUser && !['groups', 'events', 'watch', 'pages', 'search', 'people'].includes(matchUser[1])) {
      return 'user_' + matchUser[1];
    }
    return limpa;
  }

  /**
   * Valida se uma string aparenta ser um nome humano real e não lixo de interface do Facebook
   */
  function ehNomeHumanoValido(nome) {
    if (!nome || typeof nome !== 'string') return false;
    const limpo = nome.trim();
    if (limpo.length < 3 || limpo.length > 55 || limpo.includes('\n')) return false;

    // Se contiver dígitos, é contagem ("13,0 mil membros", "12 amigos", "5 posts", etc.)
    if (/\d/.test(limpo)) return false;

    const norm = normalizarTextoFb(limpo);

    if (norm.startsWith('novos') || norm.startsWith('novo ') || norm.includes('posts') || norm.includes('post')) return false;
    if (norm.includes('saiba mais') || norm.includes('membros') || norm.includes('membro')) return false;
    if (norm.includes('participar') || norm.includes('entrar no grupo') || norm.includes('convidar')) return false;

    const termosProibidos = [
      'membro', 'membros', 'mil membros', 'saiba mais', 'pessoas', 'participar',
      'entrou', 'adicionar', 'amigo', 'amigos', 'mensagem', 'ver tudo', 'grupo',
      'facebook', 'compartilhar', 'curtir', 'notificacoes', 'feed', 'gaming',
      'convidar', 'classificado', 'discussao', 'destaques', 'video', 'eventos',
      'sobre', 'arquivos', 'midia', 'reels', 'pesquisar', 'administrador', 'moderador',
      'bloquear', 'denunciar', 'sair', 'regras', 'comum', 'seguidor', 'seguidores',
      'publicacao', 'publicacoes', 'fotos', 'albuns', 'atividades', 'gerenciar',
      'configuracoes', 'ajuda', 'politica', 'termos', 'privacidade', 'cancelar', 'ver mais',
      'novos posts', 'novo post', 'posts', 'solicitacao', 'solicitacoes'
    ];

    if (termosProibidos.some(t => norm === t || norm.includes(t))) {
      return false;
    }

    if (!/[a-z]/i.test(norm)) return false;
    if (/[@#\$%&*+=_\/\\<>{}\[\]|~^·]/.test(limpo)) return false;

    return true;
  }

  /**
   * Extrai membros do DOM atual e acumula no cache persistente global
   */
  function extrairMembrosDoDom() {
    const map = window.__RESETFIT_FB_MEMBROS_CACHE__;
    const nomeGrupo = obterNomeGrupoFacebook();

    // 1. Vasculha links diretos de perfis e membros de grupos no Facebook
    const seletoresLinks = [
      'a[href*="/user/"]',
      'a[href*="profile.php"]',
      'a[role="link"]',
      'div[role="listitem"] a',
      'div[role="feed"] a',
      'div[data-visualcompletion] a'
    ];
    const links = document.querySelectorAll(seletoresLinks.join(', '));

    links.forEach(a => {
      try {
        const href = a.getAttribute('href') || '';
        if (!href) return;
        if (href.includes('/help/') || href.includes('/settings/') || href.includes('/policies/') || href.includes('/hashtag/')) return;

        const ehPerfil = href.includes('/user/') ||
                         href.includes('profile.php') ||
                         (href.includes('/groups/') && (href.includes('/user/') || href.includes('/member/'))) ||
                         (a.closest('div[role="listitem"]') !== null);

        if (!ehPerfil) return;

        // Tenta obter o nome através dos spans internos ou atributos
        let nome = '';
        const spans = Array.from(a.querySelectorAll('span')).filter(s => s.innerText && s.innerText.trim().length > 1);
        for (const s of spans) {
          const txt = s.innerText.trim();
          if (ehNomeHumanoValido(txt)) {
            nome = txt;
            break;
          }
        }

        if (!nome) {
          const aria = a.getAttribute('aria-label') || '';
          if (ehNomeHumanoValido(aria)) {
            nome = aria.trim();
          } else if (ehNomeHumanoValido(a.innerText)) {
            nome = a.innerText.trim();
          }
        }

        if (!nome || !ehNomeHumanoValido(nome)) return;

        let idUnico = extrairIdentificadorPerfilFb(href);
        if (!idUnico || idUnico.length < 3) {
          idUnico = 'nome_' + normalizarTextoFb(nome);
        }

        // Detecta cargo de admin/moderador no elemento pai
        let cargo = 'membro';
        const containerPai = a.closest('div[role="listitem"]') || a.closest('div[data-visualcompletion]') || a.parentElement?.parentElement;
        if (containerPai) {
          const txtPai = containerPai.innerText ? containerPai.innerText.toLowerCase() : '';
          if (txtPai.includes('administrador') || txtPai.includes('admin') || txtPai.includes('moderador')) {
            cargo = 'admin';
          }
        }

        const urlCompleta = href.startsWith('http') ? href : `https://www.facebook.com${href}`;

        if (!map.has(idUnico)) {
          map.set(idUnico, {
            id: idUnico,
            nome: nome,
            perfilUrl: urlCompleta,
            cargo: cargo,
            grupoOrigem: nomeGrupo,
            dataCaptura: new Date().toISOString()
          });
        } else if (cargo === 'admin') {
          const existente = map.get(idUnico);
          existente.cargo = 'admin';
          map.set(idUnico, existente);
        }
      } catch (e) {}
    });

    // 2. Vasculha elementos com role="listitem" para capturar nomes mesmo se o link estiver ofuscado
    const listItems = document.querySelectorAll('div[role="listitem"]');
    listItems.forEach(item => {
      try {
        const text = item.innerText || '';
        if (!text) return;

        const a = item.querySelector('a');
        let href = a ? (a.getAttribute('href') || '') : '';

        const linhas = text.split('\n').map(l => l.trim()).filter(Boolean);
        for (const linha of linhas) {
          if (ehNomeHumanoValido(linha)) {
            let idUnico = href ? extrairIdentificadorPerfilFb(href) : 'nome_' + normalizarTextoFb(linha);
            if (!idUnico) idUnico = 'nome_' + normalizarTextoFb(linha);

            let cargo = 'membro';
            const txtLower = text.toLowerCase();
            if (txtLower.includes('administrador') || txtLower.includes('admin') || txtLower.includes('moderador')) {
              cargo = 'admin';
            }

            if (!map.has(idUnico)) {
              map.set(idUnico, {
                id: idUnico,
                nome: linha,
                perfilUrl: href ? (href.startsWith('http') ? href : `https://www.facebook.com${href}`) : `https://www.facebook.com/search/people/?q=${encodeURIComponent(linha)}`,
                cargo: cargo,
                grupoOrigem: nomeGrupo,
                dataCaptura: new Date().toISOString()
              });
            }
            break;
          }
        }
      } catch (e) {}
    });

    leadsExtraidosCache = Array.from(map.values());
    return leadsExtraidosCache;
  }

  /**
   * Executa rolagem agressiva em todas as camadas e dispara eventos para acionar o GraphQL do Facebook
   */
  function rolarPaginaFacebookFundo() {
    window.scrollBy(0, 1600);
    window.scrollTo(0, document.body.scrollHeight || document.documentElement.scrollHeight);

    try { document.documentElement.scrollTop = document.documentElement.scrollHeight; } catch(e) {}
    try { document.body.scrollTop = document.body.scrollHeight; } catch(e) {}

    const scrollables = document.querySelectorAll('div[role="feed"], div[role="main"], div[tabindex="-1"], div[style*="overflow"]');
    scrollables.forEach(s => {
      try {
        s.scrollTop = s.scrollHeight;
        s.dispatchEvent(new Event('scroll', { bubbles: true }));
      } catch(e) {}
    });

    // Dispara eventos artificiais de scroll e wheel para despertar listeners de virtualização
    try {
      window.dispatchEvent(new Event('scroll'));
      window.dispatchEvent(new WheelEvent('wheel', { deltaY: 1000, bubbles: true }));
    } catch(e) {}
  }

  /**
   * Executa rolagem avançada / turbo com monitoramento ao vivo de membros capturados
   */
  async function executarRolagemAvancada(metaNovosContatos = 150, maxCiclos = 40, delayMs = 450) {
    if (rolagemEmExecucao) return;
    rolagemEmExecucao = true;
    cancelandoRolagemFb = false;

    const banner = document.getElementById('resetfit-fb-scroll-banner');
    const txtStatus = document.getElementById('resetfit-fb-scroll-txt');
    const txtSub = document.getElementById('resetfit-fb-scroll-sub');
    const btnNormal = document.getElementById('btn-rolar-mais-fb');
    const btnTurbo = document.getElementById('btn-rolar-turbo-fb');
    const btnMax = document.getElementById('btn-rolar-max-fb');

    if (banner) banner.style.display = 'block';
    if (btnNormal) { btnNormal.disabled = true; btnNormal.style.opacity = '0.5'; }
    if (btnTurbo) { btnTurbo.disabled = true; btnTurbo.style.opacity = '0.5'; }
    if (btnMax) { btnMax.disabled = true; btnMax.style.opacity = '0.5'; }

    const contatosIniciais = window.__RESETFIT_FB_MEMBROS_CACHE__.size;
    let ciclosSemNovos = 0;

    for (let i = 1; i <= maxCiclos; i++) {
      if (cancelandoRolagemFb) break;

      rolarPaginaFacebookFundo();
      await new Promise(r => setTimeout(r, delayMs));

      const membrosAtuais = extrairMembrosDoDom();
      const totalAtual = membrosAtuais.length;
      const novosCapturados = totalAtual - contatosIniciais;
      const adminsCount = membrosAtuais.filter(m => m.cargo === 'admin').length;

      if (txtStatus) {
        txtStatus.innerHTML = `⚡ Rolagem Turbo Ativa: <b>${totalAtual} contatos</b> (+${novosCapturados} novos)`;
      }
      if (txtSub) {
        txtSub.innerHTML = `🔄 Ciclo ${i} de ${maxCiclos} • Meta: +${metaNovosContatos} contatos • ${adminsCount} Admins`;
      }

      const elCont = document.getElementById('fb-contador-modal');
      if (elCont) {
        elCont.innerHTML = `${totalAtual} <span style="font-size: 12px; font-weight: 600; color: #64748B;">contatos (${adminsCount} Admins)</span>`;
      }

      // Se já atingiu a meta pedida, finaliza
      if (novosCapturados >= metaNovosContatos) {
        break;
      }
    }

    if (banner) banner.style.display = 'none';
    if (btnNormal) { btnNormal.disabled = false; btnNormal.style.opacity = '1'; }
    if (btnTurbo) { btnTurbo.disabled = false; btnTurbo.style.opacity = '1'; }
    if (btnMax) { btnMax.disabled = false; btnMax.style.opacity = '1'; }

    const membrosFinais = extrairMembrosDoDom();
    const adm = membrosFinais.filter(m => m.cargo === 'admin').length;
    const elCont = document.getElementById('fb-contador-modal');
    if (elCont) {
      elCont.innerHTML = `${membrosFinais.length} <span style="font-size: 12px; font-weight: 600; color: #64748B;">contatos (${adm} Admins)</span>`;
    }
    const elList = document.getElementById('fb-lista-membros-preview');
    if (elList) elList.innerHTML = renderizarListaPreviewMembros(membrosFinais);

    rolagemEmExecucao = false;
    cancelandoRolagemFb = false;
  }

  // =========================================================================
  // GESTÃO DE PÚBLICOS E CATEGORIAS (CONSULTOR, CLIENTE, CIDADES, ETC)
  // =========================================================================
  function obterPublicosSalvosFacebook() {
    const padroes = ['Consultor', 'Cliente', 'Público Geral'];
    try {
      const raw = localStorage.getItem('resetfit_fb_publicos_lista');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          parsed.forEach(p => {
            const pTrim = String(p || '').trim();
            if (pTrim && !padroes.includes(pTrim)) padroes.push(pTrim);
          });
        }
      }
    } catch(e) {}
    return padroes;
  }

  function salvarNovoPublicoStorage(novoPublico) {
    if (!novoPublico || !novoPublico.trim()) return;
    const lista = obterPublicosSalvosFacebook();
    const nomeLimpo = novoPublico.trim();
    if (!lista.includes(nomeLimpo)) {
      lista.push(nomeLimpo);
      try {
        localStorage.setItem('resetfit_fb_publicos_lista', JSON.stringify(lista));
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ resetfit_fb_publicos_lista: lista });
        }
      } catch(e) {}
    }
    try {
      localStorage.setItem('resetfit_fb_ultimo_publico_selecionado', nomeLimpo);
    } catch(e) {}
  }

  /**
   * Remove imediatamente qualquer botão flutuante antigo do rodapé (libera 100% o Messenger)
   */
  function removerBotoesFlutuantesFacebook() {
    const elementosParaRemover = document.querySelectorAll(
      '#resetfit-fb-floating-container, #litrao-fb-btn-container, [id*="litrao-fb-btn"], #btn-litrao-fb-extrair, #btn-resetfit-fb-extrair'
    );
    elementosParaRemover.forEach(el => {
      try { el.remove(); } catch (_) {}
    });
  }

  // ==========================================
  // SIDEBAR LATERAL ACOPLADA NO FACEBOOK (PRINT 3)
  // Aba vertical verde retrátil idêntica ao WhatsApp Web
  // ==========================================
  let fbSidebarDockAberta = false;

  function alternarSidebarLateralFacebook(forcarAberto = null) {
    const dock = document.getElementById('litrao-lateral-dock-fb');
    const btnAbertura = document.getElementById('litrao-lateral-tab-btn-fb');
    if (!dock) return;

    fbSidebarDockAberta = (forcarAberto !== null) ? forcarAberto : !fbSidebarDockAberta;
    dock.style.right = fbSidebarDockAberta ? '0' : '-480px';
    if (btnAbertura) {
      btnAbertura.style.display = fbSidebarDockAberta ? 'none' : 'flex';
    }
  }

  function injetarSidebarLateralFacebook() {
    // 1. Limpa resíduos de botões horizontais antigos do rodapé
    removerBotoesFlutuantesFacebook();

    if (document.getElementById('litrao-lateral-dock-fb')) return;

    // 2. Botão Flutuante de Abertura na borda direita (Verde Vertical - Print 3)
    const btnAbertura = document.createElement('div');
    btnAbertura.id = 'litrao-lateral-tab-btn-fb';
    btnAbertura.innerHTML = `<span>⚡</span><span>RESETFIT</span>`;
    btnAbertura.style.cssText = `
      position: fixed;
      right: 0;
      top: 38%;
      transform: translateY(-50%);
      z-index: 999999;
      background: linear-gradient(135deg, #10B981, #059669);
      color: #FFFFFF;
      font-weight: 800;
      font-size: 11px;
      padding: 12px 6px;
      border-radius: 8px 0 0 8px;
      cursor: pointer;
      writing-mode: vertical-rl;
      text-orientation: mixed;
      box-shadow: -4px 0 16px rgba(0,0,0,0.4);
      letter-spacing: 1px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      user-select: none;
      transition: transform 0.2s;
      display: flex;
      align-items: center;
      gap: 6px;
    `;
    btnAbertura.title = "Clique para abrir o ResetFIT na Lateral do Facebook";

    btnAbertura.addEventListener('mouseenter', () => { btnAbertura.style.transform = 'translateY(-50%) scale(1.05)'; });
    btnAbertura.addEventListener('mouseleave', () => { btnAbertura.style.transform = 'translateY(-50%) scale(1)'; });

    // 3. Container da Sidebar Lateral Acoplada no Facebook
    const dock = document.createElement('div');
    dock.id = 'litrao-lateral-dock-fb';
    dock.style.cssText = `
      position: fixed;
      right: -480px;
      top: 0;
      width: 440px;
      height: 100vh;
      z-index: 1000000;
      background: #090D16;
      box-shadow: -10px 0 35px rgba(0,0,0,0.7);
      transition: right 0.35s cubic-bezier(0.16, 1, 0.3, 1);
      display: flex;
      flex-direction: column;
      border-left: 1px solid #1E293B;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    `;

    dock.innerHTML = `
      <div style="background: #0D1424; padding: 10px 14px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #1E293B;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="background: #10B981; color: white; font-weight: 900; font-size: 10px; padding: 2px 6px; border-radius: 4px;">RESETFIT</span>
          <span style="color: #F8FAFC; font-weight: 800; font-size: 12px;">ResetFIT Facebook</span>
        </div>
        <div style="display: flex; align-items: center; gap: 6px;">
          <button id="litrao-fb-dock-telacheia" style="background: #1E293B; color: #94A3B8; border: 1px solid #334155; border-radius: 6px; padding: 4px 8px; font-size: 11px; cursor: pointer; font-weight: bold;" title="Abrir em Tela Cheia">⛶ Tela Cheia</button>
          <button id="litrao-fb-dock-fechar" style="background: #334155; color: #FFF; border: none; border-radius: 6px; padding: 4px 10px; font-size: 12px; cursor: pointer; font-weight: bold;" title="Fechar Lateral">✕</button>
        </div>
      </div>
      <iframe id="litrao-fb-dock-iframe" src="${chrome.runtime.getURL('popup.html')}" style="width: 100%; height: calc(100% - 45px); border: none; background: #090D16;"></iframe>
    `;

    document.body.appendChild(btnAbertura);
    document.body.appendChild(dock);

    btnAbertura.addEventListener('click', () => alternarSidebarLateralFacebook(true));
    dock.querySelector('#litrao-fb-dock-fechar').addEventListener('click', () => alternarSidebarLateralFacebook(false));
    dock.querySelector('#litrao-fb-dock-telacheia').addEventListener('click', () => {
      window.open(chrome.runtime.getURL('popup.html'), '_blank');
    });
  }

  function injetarBotaoFlutuanteFacebook() {
    // Redireciona para a nova barra lateral oficial
    injetarSidebarLateralFacebook();
  }

  /**
   * Abre o modal flutuante de extração na tela do Facebook
   */
  function abrirModalExtracaoFacebook() {
    let modal = document.getElementById('resetfit-fb-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'resetfit-fb-modal';
      modal.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.75);
        backdrop-filter: blur(5px);
        z-index: 1000000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 16px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      `;
      document.body.appendChild(modal);
    }

    const membros = extrairMembrosDoDom();
    const nomeGrupo = obterNomeGrupoFacebook();
    const adminsCount = membros.filter(m => m.cargo === 'admin').length;

    const publicosLista = obterPublicosSalvosFacebook();
    let publicoAtivo = 'Consultor';
    try {
      publicoAtivo = localStorage.getItem('resetfit_fb_ultimo_publico_selecionado') || 'Consultor';
    } catch(e) {}

    const publicosOptionsHtml = publicosLista.map(p => {
      const isSel = p === publicoAtivo ? 'selected' : '';
      let icone = '🎯';
      if (p.toLowerCase().includes('consultor')) icone = '👔';
      else if (p.toLowerCase().includes('cliente')) icone = '🥤';
      else if (p.toLowerCase().includes('geral')) icone = '🌐';
      else icone = '📍';
      return `<option value="${p}" ${isSel}>${icone} ${p}</option>`;
    }).join('');

    modal.innerHTML = `
      <style>
        #resetfit-fb-modal, #resetfit-fb-modal * {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
          box-sizing: border-box !important;
        }
        @keyframes resetfitProgressShimmer {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .resetfit-progress-animated {
          background-size: 200% 200% !important;
          animation: resetfitProgressShimmer 2s ease infinite !important;
        }
      </style>
      <div style="
        background: #FFFFFF;
        width: 100%;
        max-width: 530px;
        border-radius: 24px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4);
        overflow: hidden;
        border: 1px solid #CBD5E1;
        display: flex;
        flex-direction: column;
        max-height: 90vh;
      ">
        <!-- HEADER -->
        <div style="
          background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
          color: #FFFFFF !important;
          padding: 16px 20px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          border-bottom: 2px solid #3B82F6;
        ">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 38px; height: 38px; border-radius: 12px; background: #2563EB; display: flex; align-items: center; justify-content: center; font-size: 19px;">
              ⚡
            </div>
            <div>
              <h3 style="margin: 0; font-size: 15px; font-weight: 800; color: #FFFFFF !important; line-height: 1.2;">Extrator Facebook • Litrão do Reset</h3>
              <p style="margin: 3px 0 0; font-size: 11px; color: #CBD5E1 !important; font-weight: 500 !important; line-height: 1.2;">${nomeGrupo}</p>
            </div>
          </div>
          <button id="btn-fechar-modal-fb" style="
            background: rgba(255, 255, 255, 0.15);
            border: none;
            color: #FFFFFF !important;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 16px;
            font-weight: 800;
            display: flex;
            align-items: center;
            justify-content: center;
          ">✕</button>
        </div>

        <!-- CORPO -->
        <div style="padding: 18px 20px; overflow-y: auto; flex: 1;">
          
          <!-- SELEÇÃO / CRIAÇÃO DE PÚBLICO DE DESTINO NO KANBAN -->
          <div style="
            background: linear-gradient(135deg, #F0FDF4 0%, #ECFDF5 100%);
            border: 2px solid #22C55E;
            border-radius: 18px;
            padding: 14px 16px;
            margin-bottom: 14px;
            box-shadow: 0 4px 12px rgba(34, 197, 94, 0.12);
          ">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
              <span style="font-size: 11px; font-weight: 900; color: #166534; text-transform: uppercase; display: flex; align-items: center; gap: 5px; letter-spacing: 0.5px;">
                🎯 SALVAR CONTATOS NO PÚBLICO:
              </span>
              <span id="resetfit-fb-badge-publico-ativo" style="
                background: #16A34A;
                color: #FFFFFF;
                font-size: 11px;
                font-weight: 900;
                padding: 3px 12px;
                border-radius: 9999px;
                box-shadow: 0 2px 4px rgba(22, 163, 74, 0.3);
              ">${publicoAtivo}</span>
            </div>
            
            <!-- ATALHOS RÁPIDOS DE PÚBLICO (1 CLIQUE) -->
            <div style="display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 10px;">
              <button type="button" class="btn-fb-quick-publico" data-pub="Consultor" style="background: #2563EB; color: #FFFFFF; border: none; padding: 6px 14px; border-radius: 999px; font-size: 11px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(37,99,235,0.25);">
                👔 Consultor
              </button>
              <button type="button" class="btn-fb-quick-publico" data-pub="Cliente" style="background: #059669; color: #FFFFFF; border: none; padding: 6px 14px; border-radius: 999px; font-size: 11px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(5,150,105,0.25);">
                🥤 Cliente
              </button>
              <button type="button" class="btn-fb-quick-publico" data-pub="Público Geral" style="background: #475569; color: #FFFFFF; border: none; padding: 6px 14px; border-radius: 999px; font-size: 11px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px;">
                🌐 Geral
              </button>
              <button type="button" id="btn-toggle-novo-publico-fb" style="background: #D97706; color: #FFFFFF; border: none; padding: 6px 14px; border-radius: 999px; font-size: 11px; font-weight: 800; cursor: pointer; display: flex; align-items: center; gap: 4px; box-shadow: 0 2px 4px rgba(217,119,6,0.25);">
                📍 + Digitar Cidade / Outro...
              </button>
            </div>

            <!-- SELETOR DROPDOWN DE PÚBLICOS SALVOS -->
            <div style="display: flex; gap: 8px; align-items: center;">
              <select id="resetfit-fb-select-publico" style="
                flex: 1;
                padding: 8px 12px;
                border-radius: 12px;
                border: 1.5px solid #86EFAC;
                background: #FFFFFF;
                color: #14532D;
                font-size: 12px;
                font-weight: 800;
                outline: none;
                cursor: pointer;
              ">
                ${publicosOptionsHtml}
                <option value="__CRIAR_NOVO__">➕ + Criar Novo Público ou Cidade...</option>
              </select>
            </div>

            <!-- Campo dinâmico para digitar novo público / cidade customizada -->
            <div id="resetfit-fb-container-novo-publico" style="display: none; margin-top: 10px; padding: 10px; background: #FFFFFF; border-radius: 12px; border: 1.5px solid #22C55E;">
              <label style="display: block; font-size: 10px; font-weight: 900; color: #166534; text-transform: uppercase; margin-bottom: 5px;">
                Digite o nome da sua Cidade ou Público (ex: Cuiabá, Barra do Garças, VIP):
              </label>
              <div style="display: flex; gap: 6px;">
                <input type="text" id="resetfit-fb-input-novo-publico" placeholder="Ex: Cuiabá, Sinop, VIP Herbalife..." style="
                  flex: 1;
                  padding: 8px 10px;
                  border-radius: 10px;
                  border: 1.5px solid #16A34A;
                  background: #F8FAFC;
                  color: #0F172A;
                  font-size: 12px;
                  font-weight: 800;
                  outline: none;
                ">
                <button type="button" id="btn-salvar-novo-publico-fb" style="
                  background: #16A34A;
                  color: #FFFFFF;
                  border: none;
                  padding: 8px 14px;
                  border-radius: 10px;
                  font-size: 11px;
                  font-weight: 800;
                  cursor: pointer;
                  white-space: nowrap;
                  box-shadow: 0 2px 4px rgba(22,163,74,0.3);
                ">Salvar e Usar</button>
              </div>
            </div>
          </div>

          <!-- CARD DE MÉTRICAS E BOTÕES DE ROLAGEM TURBO -->
          <div style="
            background: #F8FAFC;
            border: 1.5px solid #E2E8F0;
            border-radius: 18px;
            padding: 14px;
            margin-bottom: 12px;
          ">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px; flex-wrap: wrap; gap: 6px;">
              <div>
                <div style="font-size: 10px; font-weight: 800; color: #64748B; text-transform: uppercase;">Membros Identificados na Memória</div>
                <div id="fb-contador-modal" style="font-size: 24px; font-weight: 900; color: #0F172A; margin-top: 1px;">
                  ${membros.length} <span style="font-size: 12px; font-weight: 600; color: #64748B;">contatos (${adminsCount} Admins)</span>
                </div>
              </div>
            </div>

            <!-- BOTÕES DE ROLAGEM COM QUANTIDADES CLARAS -->
            <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
              <button id="btn-rolar-mais-fb" type="button" title="Rola rápido para carregar mais contatos" style="
                flex: 1;
                background: #EEF2FF;
                color: #4338CA;
                border: 1.5px solid #C7D2FE;
                padding: 9px 10px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 800;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 4px;
              ">🔄 +50 Contatos</button>

              <button id="btn-rolar-turbo-fb" type="button" title="Rola 30x seguidas para carregar centenas de contatos" style="
                flex: 1.4;
                background: linear-gradient(135deg, #4F46E5, #7C3AED);
                color: #FFFFFF;
                border: none;
                padding: 9px 12px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 800;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 5px;
                box-shadow: 0 4px 6px -1px rgba(124, 58, 237, 0.35);
              ">⚡ Turbo (+200 a 500)</button>

              <button id="btn-rolar-max-fb" type="button" title="Rola continuamente até parar ou fim do grupo" style="
                flex: 1.4;
                background: linear-gradient(135deg, #0284C7, #0369A1);
                color: #FFFFFF;
                border: none;
                padding: 9px 12px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 800;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 5px;
                box-shadow: 0 4px 6px -1px rgba(2, 132, 199, 0.35);
              ">🚀 ROLAGEM MÁXIMA (+1.000)</button>
            </div>
          </div>

          <!-- BANNER DE STATUS DE ROLAGEM TURBO EM TEMPO REAL -->
          <div id="resetfit-fb-scroll-banner" style="
            display: none;
            background: linear-gradient(135deg, #1E1B4B, #312E81);
            color: #FFFFFF;
            padding: 12px 16px;
            border-radius: 14px;
            margin-bottom: 12px;
            border: 1.5px solid #818CF8;
            box-shadow: 0 6px 15px rgba(49, 46, 129, 0.4);
          ">
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-wrap: wrap;">
              <div style="display: flex; align-items: center; gap: 10px;">
                <span style="font-size: 20px;">⚡</span>
                <div>
                  <div id="resetfit-fb-scroll-txt" style="font-size: 12px; font-weight: 800; color: #FFFFFF;">
                    Rolando página do Facebook...
                  </div>
                  <div id="resetfit-fb-scroll-sub" style="font-size: 11px; color: #C7D2FE; margin-top: 2px;">
                    Carregando novos membros na memória...
                  </div>
                </div>
              </div>
              <button type="button" id="btn-parar-rolagem-fb" style="
                background: #EF4444;
                color: #FFFFFF;
                border: none;
                padding: 7px 14px;
                border-radius: 10px;
                font-size: 11px;
                font-weight: 800;
                cursor: pointer;
                box-shadow: 0 2px 4px rgba(239, 68, 68, 0.3);
              ">⏹️ Parar e Usar Contatos</button>
            </div>
          </div>

          <!-- BARRA DE PROGRESSO DE SINCRONIZAÇÃO EM TEMPO REAL -->
          <div id="resetfit-fb-progress-box" style="
            display: none;
            background: linear-gradient(135deg, #0F172A, #1E293B);
            border: 1px solid #3B82F6;
            border-radius: 16px;
            padding: 14px 16px;
            margin-bottom: 14px;
          ">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <div style="display: flex; align-items: center; gap: 8px;">
                <div id="resetfit-fb-progress-dot" style="width: 8px; height: 8px; border-radius: 50%; background: #10B981; box-shadow: 0 0 8px #10B981;"></div>
                <span id="resetfit-fb-progress-status" style="font-size: 12px; font-weight: 800; color: #FFFFFF !important;">
                  Conectando ao Painel do Litrão...
                </span>
              </div>
              <span id="resetfit-fb-progress-percent" style="font-size: 13px; font-weight: 900; color: #34D399 !important;">
                0%
              </span>
            </div>
            
            <div style="
              width: 100%;
              height: 12px;
              background: rgba(255, 255, 255, 0.12);
              border-radius: 9999px;
              overflow: hidden;
              position: relative;
              border: 1px solid rgba(255, 255, 255, 0.2);
            ">
              <div id="resetfit-fb-progress-bar" class="resetfit-progress-animated" style="
                width: 0%;
                height: 100%;
                background: linear-gradient(90deg, #10B981, #059669, #3B82F6, #10B981);
                border-radius: 9999px;
                transition: width 0.18s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 0 0 12px rgba(16, 185, 129, 0.6);
              "></div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px; font-size: 11px;">
              <span id="resetfit-fb-progress-count" style="color: #CBD5E1 !important; font-weight: 600;">
                0 contatos processados
              </span>
              <span style="color: #38BDF8 !important; font-weight: 700; display: flex; align-items: center; gap: 4px;">
                🛡️ Filtro Anti-Duplicação Ativo
              </span>
            </div>
          </div>

          <!-- LISTA PRÉVIA DOS CONTATOS -->
          <div style="font-size: 12px; font-weight: 700; color: #334155; margin-bottom: 8px;">
            Contatos Prontos para Sincronizar:
          </div>
          <div id="fb-lista-membros-preview" style="max-height: 170px; overflow-y: auto; border: 1px solid #E2E8F0; border-radius: 14px; padding: 6px; background: #FFFFFF;">
            ${renderizarListaPreviewMembros(membros)}
          </div>
        </div>

        <!-- FOOTER COM BOTÕES DE AÇÃO -->
        <div style="
          padding: 14px 20px;
          background: #F8FAFC;
          border-top: 1px solid #E2E8F0;
          display: flex;
          align-items: center;
          gap: 10px;
          flex-wrap: wrap;
        ">
          <button id="btn-sincronizar-fb-painel" style="
            flex: 1;
            background: linear-gradient(135deg, #16A34A 0%, #059669 100%);
            color: #FFFFFF;
            border: none;
            padding: 12px 18px;
            border-radius: 14px;
            font-size: 12px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 4px 6px -1px rgba(22, 163, 74, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s ease-in-out;
          ">
            <span>🚀 Sincronizar como <b id="resetfit-btn-txt-publico" style="background: rgba(0,0,0,0.25); padding: 2px 7px; border-radius: 6px; margin-left: 2px;">${publicoAtivo}</b> no Kanban</span>
          </button>
          <button id="btn-copiar-fb-json" style="
            background: #FFFFFF;
            color: #1E293B;
            border: 1px solid #CBD5E1;
            padding: 12px 14px;
            border-radius: 14px;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
          ">📋 Copiar</button>
        </div>
      </div>
    `;

    modal.style.display = 'flex';

    // Eventos
    document.getElementById('btn-fechar-modal-fb')?.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    document.getElementById('btn-rolar-mais-fb')?.addEventListener('click', async () => {
      await executarRolagemAvancada(50, 15, 450);
    });

    document.getElementById('btn-rolar-turbo-fb')?.addEventListener('click', async () => {
      await executarRolagemAvancada(300, 45, 400);
    });

    document.getElementById('btn-rolar-max-fb')?.addEventListener('click', async () => {
      await executarRolagemAvancada(1000, 100, 380);
    });

    document.getElementById('btn-parar-rolagem-fb')?.addEventListener('click', () => {
      cancelandoRolagemFb = true;
      const txtSub = document.getElementById('resetfit-fb-scroll-sub');
      if (txtSub) txtSub.innerText = 'Parando e processando membros capturados...';
    });

    document.getElementById('btn-sincronizar-fb-painel')?.addEventListener('click', () => {
      sincronizarComPainelLitrao();
    });

    document.getElementById('btn-copiar-fb-json')?.addEventListener('click', () => {
      copiarDadosParaClipboard();
    });

    // Funções de Gestão do Público na Interface
    const selPublico = document.getElementById('resetfit-fb-select-publico');
    const boxNovoPub = document.getElementById('resetfit-fb-container-novo-publico');
    const inNovoPub = document.getElementById('resetfit-fb-input-novo-publico');
    const btnSalvarPub = document.getElementById('btn-salvar-novo-publico-fb');
    const btnTogglePub = document.getElementById('btn-toggle-novo-publico-fb');

    function definirPublicoAtivoInterface(nomePub) {
      if (!nomePub) return;
      const nomeLimpo = nomePub.trim();
      const badge = document.getElementById('resetfit-fb-badge-publico-ativo');
      const btnTxt = document.getElementById('resetfit-btn-txt-publico');
      const sel = document.getElementById('resetfit-fb-select-publico');
      const box = document.getElementById('resetfit-fb-container-novo-publico');

      if (badge) badge.innerText = nomeLimpo;
      if (btnTxt) btnTxt.innerText = nomeLimpo;
      if (sel) {
        let optExistente = Array.from(sel.options).find(o => o.value === nomeLimpo);
        if (!optExistente) {
          const opt = document.createElement('option');
          opt.value = nomeLimpo;
          opt.innerText = `🎯 ${nomeLimpo}`;
          sel.insertBefore(opt, sel.lastElementChild);
        }
        sel.value = nomeLimpo;
      }
      if (box) box.style.display = 'none';

      try {
        localStorage.setItem('resetfit_fb_ultimo_publico_selecionado', nomeLimpo);
      } catch(e) {}
    }

    document.querySelectorAll('.btn-fb-quick-publico').forEach(btn => {
      btn.addEventListener('click', () => {
        const p = btn.getAttribute('data-pub');
        if (p) definirPublicoAtivoInterface(p);
      });
    });

    if (selPublico) {
      selPublico.addEventListener('change', () => {
        if (selPublico.value === '__CRIAR_NOVO__') {
          if (boxNovoPub) boxNovoPub.style.display = 'block';
          if (inNovoPub) { inNovoPub.focus(); inNovoPub.value = ''; }
        } else {
          definirPublicoAtivoInterface(selPublico.value);
        }
      });
    }

    if (btnTogglePub) {
      btnTogglePub.addEventListener('click', () => {
        if (boxNovoPub) {
          const aberto = boxNovoPub.style.display === 'block';
          boxNovoPub.style.display = aberto ? 'none' : 'block';
          if (!aberto && inNovoPub) inNovoPub.focus();
        }
      });
    }

    if (btnSalvarPub) {
      btnSalvarPub.addEventListener('click', () => {
        const val = inNovoPub ? inNovoPub.value.trim() : '';
        if (!val) {
          alert('Digite o nome do público ou cidade (ex: Consultor, Cliente, Cuiabá)!');
          return;
        }
        salvarNovoPublicoStorage(val);
        definirPublicoAtivoInterface(val);
      });
    }
  }

  function renderizarListaPreviewMembros(membros) {
    if (!membros || membros.length === 0) {
      return '<div style="padding: 14px; text-align: center; color: #94A3B8; font-size: 11px;">Nenhum membro detectado ainda. Clique em "Turbo (+200 a 500)"!</div>';
    }

    return membros.slice(0, 150).map(m => `
      <div style="
        padding: 6px 10px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 1px solid #F1F5F9;
        font-size: 11px;
      ">
        <div style="display: flex; align-items: center; gap: 8px;">
          <div style="
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: #2563EB;
            color: #FFFFFF;
            font-weight: 800;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
          ">
            ${m.nome.charAt(0).toUpperCase()}
          </div>
          <span style="font-weight: 700; color: #1E293B;">${m.nome}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 6px;">
          <button type="button" class="btn-resetfit-x1-copiar" data-nome="${m.nome.replace(/"/g, '&quot;')}" data-perfil="${(m.perfilUrl || '').replace(/"/g, '&quot;')}" style="
            background: #EFF6FF;
            color: #2563EB;
            border: 1px solid #BFDBFE;
            padding: 3px 8px;
            border-radius: 6px;
            font-size: 9px;
            font-weight: 800;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 3px;
          " title="Copiar mensagem personalizada com {nome} e {saudacao}">💬 Mensagem X1</button>
          ${m.cargo === 'admin'
            ? '<span style="background: #FEF3C7; color: #92400E; padding: 2px 6px; border-radius: 6px; font-size: 9px; font-weight: 800;">👑 Admin</span>'
            : '<span style="background: #F1F5F9; color: #475569; padding: 2px 6px; border-radius: 6px; font-size: 9px; font-weight: 600;">Membro</span>'
          }
        </div>
      </div>
    `).join('') + (membros.length > 150 ? `<div style="padding: 8px; text-align: center; font-size: 10px; color: #64748B; font-weight: 700;">+ ${membros.length - 150} outros contatos prontos</div>` : '');
  }

  /**
   * Sincroniza os contatos com o Painel do Litrão com Barra de Progresso Real e Anti-Duplicação
   */
  async function sincronizarComPainelLitrao() {
    const membros = extrairMembrosDoDom();
    const nomeGrupo = obterNomeGrupoFacebook();

    if (membros.length === 0) {
      alert('Nenhum membro identificado para sincronizar. Role a página do Facebook para carregar contatos.');
      return;
    }

    const btnSinc = document.getElementById('btn-sincronizar-fb-painel');
    const boxProgresso = document.getElementById('resetfit-fb-progress-box');
    const elBar = document.getElementById('resetfit-fb-progress-bar');
    const elPercent = document.getElementById('resetfit-fb-progress-percent');
    const elStatus = document.getElementById('resetfit-fb-progress-status');
    const elCount = document.getElementById('resetfit-fb-progress-count');

    const selPublico = document.getElementById('resetfit-fb-select-publico');
    const inNovoPub = document.getElementById('resetfit-fb-input-novo-publico');
    let publicoEscolhido = 'Consultor';
    if (selPublico && selPublico.value && selPublico.value !== '__CRIAR_NOVO__') {
      publicoEscolhido = selPublico.value;
    } else if (inNovoPub && inNovoPub.value.trim()) {
      publicoEscolhido = inNovoPub.value.trim();
      salvarNovoPublicoStorage(publicoEscolhido);
    }

    if (btnSinc) {
      btnSinc.disabled = true;
      btnSinc.style.opacity = '0.85';
      btnSinc.style.cursor = 'wait';
      btnSinc.innerHTML = `<span>⏳ Sincronizando para "${publicoEscolhido}"...</span>`;
    }

    if (boxProgresso) boxProgresso.style.display = 'block';

    const total = membros.length;
    const etapas = [
      { pct: 20, msg: `Conectando ao Painel do Litrão (${publicoEscolhido})...`, count: Math.max(1, Math.floor(total * 0.20)) },
      { pct: 50, msg: `Segmentando contatos no público "${publicoEscolhido}"...`, count: Math.max(1, Math.floor(total * 0.50)) },
      { pct: 75, msg: 'Aplicando filtro anti-duplicação estrito em todos os cards...', count: Math.max(1, Math.floor(total * 0.75)) },
      { pct: 95, msg: `Transmitindo leads para o grupo "${publicoEscolhido}" no Kanban...`, count: Math.max(1, Math.floor(total * 0.95)) },
      { pct: 100, msg: `Gravação concluída no público "${publicoEscolhido}"!`, count: total }
    ];

    for (const etapa of etapas) {
      if (elBar) elBar.style.width = `${etapa.pct}%`;
      if (elPercent) elPercent.innerText = `${etapa.pct}%`;
      if (elStatus) elStatus.innerText = etapa.msg;
      if (elCount) elCount.innerText = `${etapa.count} de ${total} contatos processados`;
      await new Promise(r => setTimeout(r, 180));
    }

    const pacote = {
      tipo: 'RESETFIT_SINCRONIZAR_FACEBOOK',
      grupo: nomeGrupo,
      publico: publicoEscolhido,
      total: membros.length,
      data: new Date().toISOString(),
      leads: membros.map(m => ({
        ...m,
        publico: publicoEscolhido
      }))
    };

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ resetfit_fb_pending_import: pacote }, () => {
        console.log('[ResetFIT Facebook] Pacote gravado em storage local:', pacote);
      });
      try {
        chrome.runtime.sendMessage({ tipo: 'RESETFIT_SINCRONIZAR_FACEBOOK', pacote: pacote });
      } catch (_) {}
    }

    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(JSON.stringify(pacote, null, 2));
      }
    } catch (_) {}

    if (elStatus) {
      elStatus.innerText = `✅ Sincronizado com Sucesso para "${publicoEscolhido}"!`;
      elStatus.style.color = '#34D399';
    }
    if (elCount) {
      elCount.innerHTML = `<b>${total} contatos enviados</b> para <b>"${publicoEscolhido}"</b> • Proteção contra duplicações ativa`;
    }

    if (btnSinc) {
      btnSinc.disabled = false;
      btnSinc.style.opacity = '1';
      btnSinc.style.cursor = 'pointer';
      btnSinc.style.background = 'linear-gradient(135deg, #059669 0%, #047857 100%)';
      btnSinc.innerHTML = `<span>✅ Sincronizado (${publicoEscolhido})!</span>`;
    }

    alert(`🎉 SINCRONIZAÇÃO CONCLUÍDA!\n\n${total} contatos do grupo "${nomeGrupo}" foram transmitidos para o seu Painel do Litrão do Reset!\n\n🎯 Público/Grupo no Kanban: "${publicoEscolhido}"\n🛡️ Regra Anti-Duplicação: Nenhum contato já cadastrado no painel será repetido, independente do card ou etapa em que esteja.`);
  }

  function copiarDadosParaClipboard() {
    const membros = extrairMembrosDoDom();
    if (membros.length === 0) {
      alert('Nenhum membro para copiar.');
      return;
    }
    const json = JSON.stringify(membros, null, 2);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(json).then(() => {
        alert(`✅ ${membros.length} membros copiados para a área de transferência!`);
      });
    } else {
      prompt('Copie os dados:', json);
    }
  }

  // Observa mudanças no DOM e limpa sempre qualquer botão horizontal no rodapé
  setInterval(() => {
    removerBotoesFlutuantesFacebook();
    try {
      if (window.location.href.includes('/groups/')) {
        injetarSidebarLateralFacebook();
      } else {
        const btnLateral = document.getElementById('litrao-lateral-tab-btn-fb');
        const dock = document.getElementById('litrao-lateral-dock-fb');
        if (btnLateral && !fbSidebarDockAberta) btnLateral.style.display = 'none';
        if (dock && !fbSidebarDockAberta) dock.style.right = '-480px';
      }
    } catch (_) {}
  }, 1000);

  // Inicialização Segura
  removerBotoesFlutuantesFacebook();
  injetarSidebarLateralFacebook();
  setTimeout(() => {
    removerBotoesFlutuantesFacebook();
    injetarSidebarLateralFacebook();
  }, 2000);
})();
